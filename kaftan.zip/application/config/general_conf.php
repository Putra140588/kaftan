<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
$config['delete'] = 'Delete';
$config['detail'] = "View detail";
$config['edit'] = 'Edit';
$config['akses'] = 'Access Group';
$config['title1'] = 'e-Commerce';
$config['title2'] = 'Application';
$config['suff_blank'] = 'b';

