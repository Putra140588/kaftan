<?php
/*
 * english lang
 */

//email activasi new register
$lang['etext1'] = 'Thank you for registering at <b>%s</b>.';
$lang['etext2'] = 'To be able to shop at <b>%s</b>, you must activate the account first by doing confirmation on this link %s';
$lang['etext3'] = 'If already active please login by entering email and password that have been registered.';
$lang['etitle'] = 'Click for activate';
$lang['econfirm'] = 'Confirm account registration #%s';