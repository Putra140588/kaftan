<?php
/*
 * indonesia lang
 */

//email activasi new register
$lang['etext1'] = 'Terima kasih anda telah mendaftar di <b>%s</b>.';
$lang['etext2'] = 'Untuk dapat berbelanja di <b>%s</b>, anda harus mengaktifkan akun terlebih dahulu dengan melakukan konfirmasi pada link ini %s';
$lang['etext3'] = 'Jika sudah aktif silahkan login dengan memasukan email dan password yang telah didaftarkan.';
$lang['etitle'] = 'Klik untuk aktifasi';
$lang['econfirm'] = 'Konfirmasi Pendaftaran Akun #%s';


