<div class="success"  style="display:none"><?php echo $this->session->flashdata('success')?></div>	
<div class="danger" style="display:none"><?php echo $this->session->flashdata('error')?></div>		
<div class="warning" style="display:none"><?php echo $this->session->flashdata('warning')?></div>	
<div class="info" style="display:none"><?php echo $this->session->flashdata('info')?></div>	