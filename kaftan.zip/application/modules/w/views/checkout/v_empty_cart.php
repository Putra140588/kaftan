		<section id="content">
        	<div id="breadcrumb-container">
        		<div class="container">
					<ul class="breadcrumb">
						<li><a href="<?php echo base_url()?>">Home</a></li>
						<li class="active"><?php echo lang('headcartcull')?></li>
					</ul>
        		</div>
        	</div>
        	<div class="container">
        		<div class="row">
        			<div class="col-md-12">
						<div class="xs-margin"></div>
        					<div class="no-content-comment" style="text-align:center">
						          <h2><i class="fa fa-exclamation-triangle"></i></h2>
						             <h1><?php echo lang('headcartcull')?></h1>
						          <h4><?php echo lang('desccartnull')?></h4>
						          <div class="xlg-margin"></div> 
						          <a href="<?php echo base_url(FOMODULE)?>" class="btn btn-custom-2"><?php echo lang('continueshopp')?></a>
						    </div>       					       				                                
        			</div>
        		</div>
			</div>      
        </section>
        				