
        	<div class="container">
        		<div class="row">
        			<div class="col-md-12">        				
        				<div class="row">
        					<?php $this->load->view('category/v_category_grid')?>
        					<?php $this->load->view('category/v_category_right_panel')?>      					
        				</div>      				
        			</div>
        		</div>
			</div>