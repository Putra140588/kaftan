			<div id="category-header">
        		<div class="row">
        			<div class="container">
						<div class="col-2">
							<div class="category-image">
								<img src="<?php echo $image_link?>" alt="<?php echo $name_page?>" class="img-responsive">
							</div><!-- End .category-image -->							
						</div><!-- End .col-2 -->						
						<div class="col-2 last">
							<div class="category-title">
								<h2><?php echo $name_page?></h2>
								<p><?php echo $page_description?></p>
								<?php 
								/*
								if ($page_link != '' && $page_btn != ''){
									echo '<a href="'.base_url(FOMODULE.'/'.$page_link.'-3.html').'" class="btn btn-custom">'.$page_btn.'</a>';
								}*/?>								
							</div>
						</div>
    				</div>
        		</div>
        	</div>