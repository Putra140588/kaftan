<ul class="nav-tabs nav-justified clearfix" id="mytab">
      <li id="myaccount"><a href="<?php echo base_url(FOMODULE.'/customer/my_account.html')?>"><?php echo lang('account')?></a></li>
      <li id="myorder"><a href="<?php echo base_url(FOMODULE.'/customer/my_order.html')?>"><?php echo lang('myorder')?></a></li>
      <li><a href="<?php echo base_url(FOMODULE.'/customer/pay_confirm.html')?>"><?php echo lang('tf6')?> </a></li>
</ul>