<section id="content" class="no-content">        	
        	<div class="lg-margin"></div><!-- Space -->
        	<div class="container">
        		<div class="row">
        			<div class="col-md-12">
        				<div class="no-content-comment">
                            <h2>404</h2>
                            <h3>It's not my fault buddy! <br> I think you got lost.</h3>
                        </div>
        			</div>
        		</div>
			</div>      
        </section> 