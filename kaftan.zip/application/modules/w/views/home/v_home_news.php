 <div id="latestnews-slider-container" class="carousel-wrapper">
                            <header class="content-title">
                                <div class="title-bg">
                                    <h2 class="title">Latest News</h2>
                                </div><!-- End .title-bg -->
                            </header>
                                <div class="carousel-controls">
                                    <div id="latestnews-slider-prev" class="carousel-btn carousel-btn-prev">
                                    </div><!-- End .carousel-prev -->
                                    <div id="latestnews-slider-next" class="carousel-btn carousel-btn-next carousel-space">
                                    </div><!-- End .carousel-next -->
                                </div><!-- End .carousel-controllers -->
                                <div class="sm-margin"></div><!-- space -->
                                <div class="row">
                                    <ul class="latestnews-slider owl-carousel">
                                        <li>
                                            <a href="single.html">
                                                <figure class="latestnews-media-container">
                                                    <img src="<?php echo base_url()?>assets/fo/images/blog/post6-small.jpg" alt="lats post" class="img-responsive">
                                                </figure>
                                            </a>
                                            <h3><a href="single.html">35% Discount on second purchase!</a></h3>
                                            <p>Sed blandit nulla nec nunc ullamcorper tristique. Maurisadipiscing cursus ante ultricies dictum sed lobortis. Nulla iaculis auctor libero, varius adipiscing sapien bibendum vel. In placerat arcu.</p>
                                            <div class="latestnews-meta-container clearfix">
                                                <div class="pull-left">
                                                    <a href="#">Read More...</a>
                                                </div><!-- End .pull-left -->
                                                <div class="pull-right">
                                                    12.05.2013
                                                </div><!-- End .pull-right -->
                                            </div><!-- End .latest-posts-meta-container -->
                                        </li>
                                        <li>
                                            <a href="single.html">
                                                <figure class="latestnews-media-container">
                                                    <img src="<?php echo base_url()?>assets/fo/images/blog/post7-small.jpg" alt="lats post" class="img-responsive">
                                                </figure>
                                            </a>
                                            <h3><a href="single.html">New Arrivals.</a></h3>
                                            <p>Aiquam mauris libero, suscipit sed ornare ac, suscipit non felis. Fusce sit amet orci justo, a ultrices urna cursus. Suspendisse mauris nibh, tristique eget consectetur a fermentum.</p>
                                            <div class="latestnews-meta-container clearfix">
                                                <div class="pull-left">
                                                    <a href="#">Read More...</a>
                                                </div><!-- End .pull-left -->
                                                <div class="pull-right">
                                                    10.05.2013
                                                </div><!-- End .pull-right -->
                                            </div><!-- End .latest-posts-meta-container -->
                                        </li>
                                                
                                        <li>
                                            <a href="single.html">
                                                <figure class="latestnews-media-container">
                                                    <img src="<?php echo base_url()?>assets/fo/images/blog/post8-small.jpg" alt="lats post" class="img-responsive">
                                                </figure>
                                            </a>
                                            <h3><a href="#">LookBook Spring-Summer 2013</a></h3>
                                            <p>Nec interdum auctor, sem velit porttitor est, id iaculis mi elit id mi. Etiam dapibus mattis sapien, blandit molestie nunc venenatis ut. Phasellus imperdiet laciniaest, nec convallis dolor aliquet ac. </p>
                                            <div class="latestnews-meta-container clearfix">
                                                <div class="pull-left">
                                                    <a href="#">Read More...</a>
                                                </div><!-- End .pull-left -->
                                                <div class="pull-right">
                                                    8.05.2013
                                                </div><!-- End .pull-right -->
                                            </div><!-- End .latest-posts-meta-container -->
                                        </li>
                                        <li>
                                            <a href="single.html">
                                                <figure class="latestnews-media-container">
                                                    <img src="<?php echo base_url()?>assets/fo/images/blog/post6-small.jpg" alt="lats post" class="img-responsive">
                                                </figure>
                                            </a>
                                            <h3><a href="#">New jeans on sales!</a></h3>
                                            <p>Sed blandit nulla nec nunc ullamcorper tristique. Maurisadipiscing cursus ante ultricies dictum sed lobortis. Nulla iaculis auctor libero, varius adipiscing sapien bibendum vel. In placerat arcu.</p>
                                            <div class="latestnews-meta-container clearfix">
                                                <div class="pull-left">
                                                    <a href="#">Read More...</a>
                                                </div><!-- End .pull-left -->
                                                <div class="pull-right">
                                                    8.05.2013
                                                </div><!-- End .pull-right -->
                                            </div><!-- End .latest-posts-meta-container -->
                                        </li>
                                    </ul>
                                </div><!-- End .row -->
                            </div><!-- End .latestnews-slider-container -->