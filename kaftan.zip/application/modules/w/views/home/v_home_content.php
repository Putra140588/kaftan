		<section id="content">
        	<div class="container">
        		<div class="row">
        			<div class="col-md-12">
        				<?php $this->load->view('v_alert_boxes')?>
                        <?php $this->load->view('home/v_home_slider_banner')?>
                        <div class="md-margin"></div>
                        <?php $this->load->view('home/v_home_recomend')?>							
                        <div class="md-margin"></div>
                        <?php $this->load->view('home/v_home_banner')?>	        					  					
                        <div class="lg-margin"></div>                       	
                    </div>
                </div>
             </div>
 			<?php $this->load->view('home/v_home_promotion')?>		                    
            <div class="lg-margin"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                    <?php $this->load->view('home/v_home_top_seller')?>                       
                        <div class="lg-margin"></div>					
					<?php //$this->load->view('home/v_home_brands')?>       			
        				
        			</div>
        		</div>
			</div>      
        </section>