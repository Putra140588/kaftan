					<div class="row">
                            <div class="col-md-4 col-sm-4 col-xs-12 service-box-container small-services">
                                <div class="services-box">
                                    <span class="small-service-icon small-service-delivery"></span>  
                                    <h3>
                                        <a href="#">Responcive Design</a>
                                        <span class="small-bottom-border"></span>
                                    </h3>
                                    <p>Cras pellentesque, nisi ac tempus pellentesque, orci sem commodo urna,amet egestas ipsum orci sit amet tellus. Mauris eu ante felis.</p>
                                </div><!-- End .services-box -->
                            </div><!-- End .col-md-4 -->
                            <div class="col-md-4 col-sm-4 col-xs-12 service-box-container small-services">
                                <div class="services-box">
                                    <span class="small-service-icon small-service-customer"></span>
                                    <h3>
                                        <a href="#">Powerful Amin Panel</a>
                                        <span class="small-bottom-border"></span>
                                    </h3>
                                    <p>Etiam dapibus mattis sapien, blandit molestie nunc venenatis ut. Phasellus imperdiet lacinia est, nec convallis dolor aliquet ac.</p>
                                </div><!-- End .services-box -->
                            </div><!-- End .col-md-4 -->
                            <div class="col-md-4 col-sm-4 col-xs-12 service-box-container small-services">
                                <div class="services-box">
                                    <span class="small-service-icon small-service-secure"></span>
                                    <h3>
                                        <a href="#">Awesome Sliders</a>
                                        <span class="small-bottom-border"></span>
                                    </h3>
                                    <p>Duis a dignissim nulla. Phasellus lacinia aliquam lorem, a consequat erat interdum nec. Aenean ut leo sem, id gravida tortor.</p>
                                </div><!-- End .services-box -->
                            </div><!-- End .col-md-4 -->
                        </div><!-- End .row -->