 <div id="inner-header">               
         <?php $this->load->view('w/header/v_search_inner_header')?>
         <?php $this->load->view('w/header/v_menu_inner_header')?>
 </div>