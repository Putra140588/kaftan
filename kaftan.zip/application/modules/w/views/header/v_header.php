<header id="header" class="header5">
     <?php $this->load->view('w/header/v_top_header')?>
     <?php $this->load->view('w/header/v_inner_header')?>           
</header>
