<div class="loading"></div>
<div class="modal fade" id="MyModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true"></div>                                                                  
<footer id="footer">
     <?php $this->load->view('w/footer/v_top_footer')?>
     <?php $this->load->view('w/footer/v_inner_footer')?>
     <?php $this->load->view('w/footer/v_bottom_footer')?>           
</footer>