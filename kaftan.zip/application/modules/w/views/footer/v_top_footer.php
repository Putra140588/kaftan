			<div id="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-12 widget">
                            <div class="title-bg">
                                <h3><?php echo lang('new')?></h3>
                            </div>
                            <div class="footer-popular-slider flexslider footerslider">
                                <ul class="slides">
                                    <?php echo $new?>                                
                                </ul>
                            </div>
                            <div class="md-margin visible-xs"></div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12 widget">
                            <div class="title-bg">
                                <h3><?php echo lang('featured')?></h3>
                            </div>
                            <div class="footer-popular-slider flexslider footerslider">
                                <ul class="slides">
                                    <?php echo $featured?>                                
                                </ul>
                            </div>
                            <div class="md-margin visible-xs"></div>
                        </div>
                         <div class="col-md-4 col-sm-4 col-xs-12 widget">
                            <div class="title-bg">
                                <h3><?php echo lang('top')?></h3>
                            </div>
                            <div class="footer-popular-slider flexslider footerslider">
                                <ul class="slides">
                                    <?php echo $top?>                                
                                </ul>
                            </div>
                            <div class="md-margin visible-xs"></div>
                        </div>                                           
                    </div>
                </div>
            </div>