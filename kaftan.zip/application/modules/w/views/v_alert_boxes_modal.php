<div class="success_modal"  style="display:none"><?php echo $this->session->flashdata('success')?></div>	
<div class="danger_modal" style="display:none"><?php echo $this->session->flashdata('error')?></div>		
<div class="warning_modal" style="display:none"><?php echo $this->session->flashdata('warning')?></div>	
<div class="info_modal" style="display:none"><?php echo $this->session->flashdata('info')?></div>	