									  <div class="form-group required">
											<label class="col-sm-4 control-label"> Province </label>
											<div class="col-sm-2" id="province">
												<select class="chosen-select form-control" name="province" data-placeholder="Choose a province" required>
													<option value="" />																			
												</select>												
											</div>
										</div>	
										<div class="form-group required">
											<label class="col-sm-4 control-label"> City </label>
											<div class="col-sm-2" id="cities">
												<select class="chosen-select form-control" name="city" data-placeholder="Choose a city" required>
													<option value="" />																			
												</select>												
											</div>
										</div>	
										<div class="hr hr-double hr-dotted hr18"></div>		
										<div class="row">											
											<div class="col-lg-6">
												<div class="widget-header">
													<h4 class="widget-title lighter"><i class="ace fa fa-road"></i> <?php echo $title1?></h4>
												</div>		
												<div id="tbl1"></div>										
											</div>											
											<div class="col-lg-6">
												<div class="widget-header">
													<h4 class="widget-title lighter"><i class="ace fa fa-truck"></i> <?php echo $title2?></h4>
												</div>
												<div id="tbl2"></div>	
											</div>
										</div>