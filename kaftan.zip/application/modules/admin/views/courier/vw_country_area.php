										
										<div class="hr hr-double hr-dotted hr18"></div>		
										<div class="row">											
											<div class="col-lg-6">
												<div class="widget-header">
													<h4 class="widget-title lighter"><i class="ace fa fa-road"></i> <?php echo $title1?></h4>
												</div>		
												<div id="tbl1"><?php $this->load->view($table1)?></div>										
											</div>												
											<div class="col-lg-6">
												<div class="widget-header">
													<h4 class="widget-title lighter"><i class="ace fa fa-truck"></i> <?php echo $title2?></h4>
												</div>		
												<div id="tbl2"><?php $this->load->view($table2)?></div>										
											</div>											
										</div>