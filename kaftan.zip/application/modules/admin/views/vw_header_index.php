					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url(MODULE.'/'.$class)?>">Home</a>
							</li>

							<li>
								<?php echo $page_title?>
							</li>							
						</ul><!-- /.breadcrumb -->
					</div>