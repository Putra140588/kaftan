			<div class="main-content">
				<div class="main-content-inner">
					<div class="page-content">						
						<?php $this->load->view('vw_page_header')?>
						<div class="row">
							<div class="col-xs-12" id="bg-image">							
								<!-- PAGE CONTENT BEGINS -->								
									<h1><i class="ace-icon fa fa-check green"></i> Welcome to
									<strong class="white">
										<?php echo $this->config->item('title1').' '.$this->config->item('title2')?>								
									</strong></h1>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->