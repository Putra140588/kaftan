<div class="widget-header">
		<h4 class="widget-title lighter"><?php echo $page_title?><?php echo isset($sub_title) ? ' <small><i class="ace-icon fa fa-angle-double-right"></i> '.$sub_title.'</small>' : '';?></h4>	
</div>