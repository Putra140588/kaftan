<div id="navbar" class="navbar navbar-default    navbar-collapse       h-navbar ace-save-state">
			<div class="navbar-container ace-save-state" id="navbar-container">
				<div class="navbar-header pull-left">
					<?php $photo = ($this->session->userdata('photo') == '') ? 'avatar2.png' : $this->session->userdata('photo');?>
					<a href="<?php echo base_url(MODULE)?>" class="navbar-brand">
						<small>
							<i class="fa fa-leaf"></i>
							<?php echo $this->config->config['title1'].' '.$this->config->config['title2']?>
						</small>
					</a>
					<button class="pull-right navbar-toggle navbar-toggle-img collapsed" type="button" data-toggle="collapse" data-target=".navbar-buttons,.navbar-menu">
						<span class="sr-only">Toggle user menu</span>

						<img src="<?php echo base_url()?>assets/images/avatars/<?php echo $photo?>" alt="#" />
					</button>

					<button class="pull-right navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#sidebar">
						<span class="sr-only">Toggle sidebar</span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>
					</button>
				</div>
				<div class="navbar-buttons navbar-header pull-right  collapse navbar-collapse" role="navigation">
					<ul class="nav ace-nav">				
						<?php $this->load->view('header_notif/vw_notif_neworder')?>
						<?php $this->load->view('header_notif/vw_notif_newcustomer')?>
						<?php $this->load->view('header_notif/vw_notif_newpayment')?>
						<?php $this->load->view('header_notif/vw_notif_paymentconfirmed')?>
						<?php $this->load->view('header_notif/vw_notif_indent')?>
						<li class="light-blue dropdown-modal user-min">
							<a data-toggle="dropdown" href="#" class="dropdown-toggle">
								<img class="nav-user-photo" src="<?php echo base_url()?>assets/images/avatars/<?php echo $photo?>" alt="#" />
								<span class="user-info">
									<small>Welcome,
									<?php echo $this->session->userdata('first_name')?></small>
								</span>
								<i class="ace-icon fa fa-caret-down"></i>
							</a>

							<ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
								<li>
									<a href="#">
										<i class="ace-icon fa fa-cog"></i>
										Settings
									</a>
								</li>

								<li>
									<a href="profile.html">
										<i class="ace-icon fa fa-user"></i>
										Profile
									</a>
								</li>

								<li class="divider"></li>

								<li>
									<a href="<?php echo base_url('admin/login/logout')?>">
										<i class="ace-icon fa fa-power-off"></i>
										Logout
									</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>				
			</div><!-- /.navbar-container -->
		</div>