<div class="success" style="display:none"><?php echo $this->session->flashdata('success')?></div>
<div class="warning" style="display:none"><?php echo $this->session->flashdata('warning')?></div>
<div class="danger" style="display:none"><?php echo $this->session->flashdata('danger')?></div>	
