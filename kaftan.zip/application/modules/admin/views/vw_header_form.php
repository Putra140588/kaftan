<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon glyphicon glyphicon-step-backward "></i>
								<a href="javascript:void(0)" onclick="history.back()">Go Back</a>
							</li>
							<li>
								<?php echo $page_title?>
							</li>							
						</ul>						
				 </div>