
<footer>
Copyright &copy;  2016 | <a href="<?php echo base_url()?>" target="_blank"> PT Barcode Mart Indonesia</a> | All Rights Reserved.
</footer>
</body>
</html>