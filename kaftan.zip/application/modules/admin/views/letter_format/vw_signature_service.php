	<div class="left">
		<div class="notice-set"></div>
		<h2 class="name">Service Engineer</h2>
		<?php echo $fne.' '.$fnl?>
		<div class="notice-left">
			<h2>..............................</h2>
			<i>Signature / Company Stamp</i>
		</div>
	</div>
	<div class="right">
		<div class="notice-set"></div>
		<h2 class="name">Customer's Acknowledgement</h2>
		<div style="padding-top: 20px"></div>
		<div class="notice-left">
			<h2>..............................</h2>
			<i>Signature / Company Stamp</i>
		</div> 
	</div>