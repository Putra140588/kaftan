							<table class="display wrap dt-tables" cellspacing="0" width="100%" value="<?php echo base_url('admin/'.$class.'/get_product')?>">
									<thead>
						            <tr>
							            <th>#</th>					            									
										<th>ID Product</th>																											
										<th>Product</th>	
										<th>Category</th>										
										<th>Supplier</th>	
										<th>Manufacture</th>																																																									
										<th class="no-sort">Actions</th>																																																																			
									</tr>
			       				 </thead>
			       				 <thead>
									<tr>
										<td></td>
										<td><input type="text" id="1" class="search-input"></td>
										<td><input type="text" id="2" class="search-input"></td>
										<td><input type="text" id="3" class="search-input"></td>
										<td><input type="text" id="4" class="search-input"></td>
										<td><input type="text" id="5" class="search-input"></td>																													
										<td></td>																																
									</tr>
								</thead>	
								</table>