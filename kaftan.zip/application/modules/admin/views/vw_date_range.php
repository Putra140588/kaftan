		<div class="input-daterange input-group">
			<input type="text" id="<?php echo $min?>" class="date-picker input-sm form-control" name="min" placeholder="Date From" data-date-format="yyyy-mm-dd" />
			<span class="input-group-addon">
				<i class="fa fa-exchange"></i>
			</span>
			<input type="text" class="date-picker input-sm form-control" id="<?php echo $max?>" name="max" placeholder="Date To" data-date-format="yyyy-mm-dd"/>
		</div>
	
