					<div class="page-header">
							<h1>
								<?php echo $page_title?>
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									<?php echo $this->session->userdata('first_name').' '.$this->session->userdata('last_name')?>
								</small>
							</h1>
						</div><!-- /.page-header -->